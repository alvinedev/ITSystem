@extends('templates.admin')

@section('title','dashboard')

@section('body')

@endsection