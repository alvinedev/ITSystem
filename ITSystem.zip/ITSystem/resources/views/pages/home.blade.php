@extends('templates.user')

@section('title',$title)

@section('body')

@endsection