<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ipinventory extends Model
{
    //
}
