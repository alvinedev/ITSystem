<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('titleHead'); ?>
    <ol class="breadcrumb">
    	<li><a href="/">HOME</a></li>
    	<li><a href="/ipinventory">IP INVENTORY</a></li>
    	<li class="active">ADD</li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

	<div class="col-md-12">
		<div class="alert alert-info">
		
		  <strong>NOTE: </strong> Select Name and Assign IP Address.
		</div>

		<?php echo Form::open(['action'=>'IpinventoriesController@store','method'=>'POST','class'=>'ipinven']); ?>

		<div class="col-md-6">
			<div class="panel panel-default">
				<div class="panel-heading">SUBJECT</div>

				<div class="panel-body">
					<div class="form-group">
						<?php echo e(Form::label('name','NAME:')); ?>

						<select id="name" name="name" class="form-control ipinven-name">
							<option value="" selected="selected" disabled="disabled">Choose Name</option>
							<?php $__currentLoopData = $sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
					<div class="form-group">
						<?php echo e(Form::label('location','DEPARTMENT: ')); ?>

						<?php echo e(Form::text('location','',['class'=>'form-control','readonly'=>'readonly'])); ?>

					</div>

				</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="panel panel-default">
				<div class="panel-heading">IP ADDRESS</div>
				
				<div class="panel-body">
					<div class="form-group">
						<?php echo e(Form::label('ipaddress','IP ADDRESS:')); ?>

						<select id="ipaddress" name="ipaddress" class="form-control ipinven-ip">
						<option value="" selected="selected" disabled="disabled">Choose IP Address</option>
							<?php $__currentLoopData = $ip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($p->id); ?>"><?php echo e($p->ipaddress); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
					<div class="form-group">
						<?php echo e(Form::label('subnet_mask','SUBNET MASK')); ?>

						<?php echo e(Form::text('subnet_mask','',['class'=>'form-control','readonly'=>'readonly'])); ?>

					</div>
					<div class="form-group">
						<?php echo e(Form::label('default_gateway','DEFAULT GATEWAY')); ?>

						<?php echo e(Form::text('default_gateway','',['class'=>'form-control','readonly'=>'readonly'])); ?>

					</div>
					<div class="form-group">
						<?php echo e(Form::label('dns_server1','DNS SERVER 1')); ?>

						<?php echo e(Form::text('dns_server1','',['class'=>'form-control','readonly'=>'readonly'])); ?>

					</div>

				</div>
			</div>
		</div>
		<div class="col-md-12">
		
		</div>
		<?php echo e(Form::submit('SAVE',['class'=>'btn btn-primary btn-block'])); ?>

		<?php echo Form::close(); ?>


	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>