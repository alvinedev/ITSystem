<?php $__env->startSection('title',$title); ?>

<?php $__env->startSection('titleHead'); ?>
    <ol class="breadcrumb">
    	<li><a href="/">HOME</a></li>
    	<li><a href="/history">HISTORY</a></li>
    	<?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $his): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	<li class="active">DISPLAY - <?php echo e(strtoupper($his->module)); ?></li>
    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

	<div class="col-md-12">
		<?php
			$before = array();
			$after = array();
		?>

		<br />
		<?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $his): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($his->module == 'subjects'): ?>
				
				<?php if($his->action == 'add'): ?>
					<?php
						$before = explode(',',$his->before);
					?>
					<div class="col-md-4 col-md-offset-4 ">
						<div class="actual_container">
							<?php echo e($his->name); ?>

						</div>
						<p class="actual_text">ACTUAL NAME</p>
					</div>
					<div class="col-md-6 col-md-offset-3">
						<div class="panel panel-default">
							<div class="panel-heading">TEXT (ADD)</div>
							
							<div class="panel-body">
								<div class="col-md-6 col-sm-6">NAME</div>
								<div class="col-md-6 col-sm-6"><?php echo e($before['0']); ?></div>
								<div class="col-md-6 col-sm-6">DEPARTMENT</div>
								<div class="col-md-6 col-sm-6"><?php echo e($before['3']); ?></div>
								<div class="col-md-6 col-sm-6">COMPUTER NAME</div>
								<div class="col-md-6 col-sm-6"><?php echo e($before['1']); ?></div>
								<div class="col-md-6 col-sm-6">DOMAIN NAME</div>
								<div class="col-md-6 col-sm-6"><?php echo e($before['2']); ?></div>
								
								
							</div>
						</div>
						<div class="col-md-6">
							<div class="his_date_text">
								<?php echo e($his->created_at); ?>

							</div>
							<p class="actual_text">CREATED DATE</p>
						</div>
						<div class="col-md-6">
							<div class="his_date_text">
								<?php echo e($his->updated_at); ?>

							</div>
							<p class="actual_text">LATEST UPDATED DATE</p>
						</div>
					</div>
				<?php elseif($his->action == 'edit'): ?>
					
					<?php
						$before = explode(',',$his->before);
						$after = explode(',',$his->after);
					?>
					<div class="col-md-4 col-md-offset-4 ">
						<div class="actual_container">
							<?php echo e($his->name); ?>

						</div>
						<p class="actual_text">ACTUAL NAME</p>
					</div>

					
					<div class="col-md-6">
						<div class="panel panel-default">
							<div class="panel-heading">BEFORE (EDIT)</div>
							
							<div class="panel-body">
								<div class="col-md-6 col-sm-6">NAME</div>
								<div class="col-md-6 col-sm-6"><?php echo e($before['0']); ?></div>
								<div class="col-md-6 col-sm-6">DEPARTMENT</div>
								<div class="col-md-6 col-sm-6"><?php echo e($before['3']); ?></div>
								<div class="col-md-6 col-sm-6">COMPUTER NAME</div>
								<div class="col-md-6 col-sm-6"><?php echo e($before['1']); ?></div>
								<div class="col-md-6 col-sm-6">DOMAIN NAME</div>
								<div class="col-md-6 col-sm-6"><?php echo e($before['2']); ?></div>
								
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="panel panel-default">
							<div class="panel-heading">AFTER (EDIT)</div>
							
							<div class="panel-body">
								<div class="col-md-6 col-sm-6">NAME</div>
								<div class="col-md-6 col-sm-6"><?php echo e($after['0']); ?></div>
								<div class="col-md-6 col-sm-6">DEPARTMENT</div>
								<div class="col-md-6 col-sm-6"><?php echo e($after['3']); ?></div>
								<div class="col-md-6 col-sm-6">COMPUTER NAME</div>
								<div class="col-md-6 col-sm-6"><?php echo e($after['1']); ?></div>
								<div class="col-md-6 col-sm-6">DOMAIN NAME</div>
								<div class="col-md-6 col-sm-6"><?php echo e($after['2']); ?></div>
								
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-md-offset-4 col-sm-offset-4"> 
						<div class="his_date_text">
							<?php echo e($his->created_date); ?>

						</div>
						<p class="actual_text">DATE / TIME</p>
					</div>
				<?php elseif($his->action == 'DELETE'): ?>
					<?php echo e("delete"); ?>

				<?php else: ?>
					<?php echo e("no action found"); ?>

				<?php endif; ?>
			<?php elseif($his->module == 'ipaddress'): ?>
				
				<?php if($his->action == 'add'): ?>
					
					<?php
						$before = explode(',',$his->before);
					?>

						<div class="col-md-4 col-md-offset-4 ">
							<div class="actual_container">
								<?php echo e($his->ipaddress); ?>

							</div>
							<p class="actual_text">ACTUAL IP ADDRESS</p>
						</div>
						<div class="col-md-6 col-md-offset-3">
							<div class="panel panel-default">
								<div class="panel-heading">TEXT (ADD)</div>
								
								<div class="panel-body">
									<div class="col-md-6 col-sm-6">IP ADDRESS</div>
									<div class="col-md-6 col-sm-6"><?php echo e($before['0']); ?></div>
									<div class="col-md-6 col-sm-6">SUBNET MASK</div>
									<div class="col-md-6 col-sm-6"><?php echo e($before['1']); ?></div>
									<div class="col-md-6 col-sm-6">DEFAULT GATEWAY</div>
									<div class="col-md-6 col-sm-6"><?php echo e($before['2'] == null?"N/A":$before['2']); ?></div>
									<div class="col-md-6 col-sm-6">DNS SERVER1</div>
									<div class="col-md-6 col-sm-6"><?php echo e($before['3'] == null?"N/A":$before['3']); ?></div>
									<div class="col-md-6 col-sm-6">DNS SERVER2</div>
									<div class="col-md-6 col-sm-6"><?php echo e($before['4'] == null?"N/A":$before['4']); ?></div>
									
								</div>
							</div>
							<div class="col-md-6">
								<div class="his_date_text">
									<?php echo e($his->created_at); ?>

								</div>
								<p class="actual_text">CREATED DATE</p>
							</div>
							<div class="col-md-6">
								<div class="his_date_text">
									<?php echo e($his->updated_at); ?>

								</div>
								<p class="actual_text">LATEST UPDATED DATE</p>
							</div>
						</div>
						
					
				<?php elseif($his->action == 'edit'): ?>
				
				<?php
					$before = explode(',',$his->before);
					$after = explode(',',$his->after);
				?>
				<div class="col-md-4 col-md-offset-4 ">
					<div class="actual_container">
						<?php echo e($his->ipaddress); ?>

					</div>
					<p class="actual_text">ACTUAL IP ADDRESS</p>
				</div>
				<div class="col-md-6">
					<div class="panel panel-default">
						<div class="panel-heading">BEFORE (EDIT)</div>
						
						<div class="panel-body">
							<div class="col-md-6 col-sm-6">IP ADDRESS</div>
							<div class="col-md-6 col-sm-6"><?php echo e($before['0']); ?></div>
							<div class="col-md-6 col-sm-6">SUBNET MASK</div>
							<div class="col-md-6 col-sm-6"><?php echo e($before['1']); ?></div>
							<div class="col-md-6 col-sm-6">DEFAULT GATEWAY</div>
							<div class="col-md-6 col-sm-6"><?php echo e($before['2'] == null?"N/A":$before['2']); ?></div>
							<div class="col-md-6 col-sm-6">DNS SERVER1</div>
							<div class="col-md-6 col-sm-6"><?php echo e($before['3'] == null?"N/A":$before['3']); ?></div>
							<div class="col-md-6 col-sm-6">DNS SERVER2</div>
							<div class="col-md-6 col-sm-6"><?php echo e($before['4'] == null?"N/A":$before['4']); ?></div>
							
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="panel panel-default">
						<div class="panel-heading">AFTER (EDIT)</div>
						
						<div class="panel-body">
							<div class="col-md-6 col-sm-6">IP ADDRESS</div>
							<div class="col-md-6 col-sm-6"><?php echo e($after['0']); ?></div>
							<div class="col-md-6 col-sm-6">SUBNET MASK</div>
							<div class="col-md-6 col-sm-6"><?php echo e($after['1']); ?></div>
							<div class="col-md-6 col-sm-6">DEFAULT GATEWAY</div>
							<div class="col-md-6 col-sm-6"><?php echo e($after['2'] == null?"N/A":$after['2']); ?></div>
							<div class="col-md-6 col-sm-6">DNS SERVER1</div>
							<div class="col-md-6 col-sm-6"><?php echo e($after['3'] == null?"N/A":$after['3']); ?></div>
							<div class="col-md-6 col-sm-6">DNS SERVER2</div>
							<div class="col-md-6 col-sm-6"><?php echo e($after['4'] == null?"N/A":$after['4']); ?></div>
							
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-4 col-md-offset-4 col-sm-offset-4"> 
					<div class="his_date_text">
						<?php echo e($his->created_date); ?>

					</div>
					<p class="actual_text">DATE / TIME</p>
				</div>
				<?php elseif($his->action == 'DELETE'): ?>
				<?php else: ?>
					<?php echo e("no action found"); ?>

				<?php endif; ?>
			<?php elseif($his->module == 'Ipinventory'): ?>
				<?php echo e($his->module." ".$his->action); ?>

				<?php if($his->action == 'ADD'): ?>
				<?php echo e($history); ?>

				<?php elseif($his->action == 'EDIT'): ?>
				<?php elseif($his->action == 'DELETE'): ?>
				<?php else: ?>
					<?php echo e("no action found"); ?>

				<?php endif; ?>
			<?php else: ?>
				<?php echo e("Nothing to Show"); ?>

				<?php if($his->action == 'ADD'): ?>
				<?php elseif($his->action == 'EDIT'): ?>
				<?php elseif($his->action == 'DELETE'): ?>
				<?php else: ?>
					<?php echo e("no action found"); ?>

				<?php endif; ?>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>