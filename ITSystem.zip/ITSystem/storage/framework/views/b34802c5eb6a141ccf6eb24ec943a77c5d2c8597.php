<?php $__env->startSection('title','dashboard'); ?>

<?php $__env->startSection('body'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>