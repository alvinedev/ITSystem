<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('titleHead'); ?>
    <ol class="breadcrumb">
    	<li><a href="/">HOME</a></li>
    	<li><a href="/reports">REPORTS</a></li>
    	<li class="active">SHOW</li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

	<div class="col-md-12">
		<div class="col-md-6">
			<div class="panel panel-default">
			<div class="panel-heading">PROBLEM(S)</div>

				<div class="panel-body">
					<div class="form-group">
						<?php echo e(Form::textarea('problem','',['class'=>'form-control'])); ?>

					</div>

				</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="panel panel-default">
			<div class="panel-heading">INFORMATION</div>

				<div class="panel-body">

				</div>
			</div>
		</div>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>