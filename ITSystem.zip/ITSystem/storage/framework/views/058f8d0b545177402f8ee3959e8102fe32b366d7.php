<?php $__env->startSection('title',$title); ?>

<?php $__env->startSection('titleHead'); ?>
<ol class="breadcrumb">
	<li><a href="/">HOME</a></li>
	<li class="active">HISTORY</li>
</ol>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<div class="col-md-8 col-md-offset-2">
	<table class="table table-hover">
		<thead> 
			<tr> 
				<th>#</th> 
				<th>NAME</th>
				<th>MODULE</th>
				<th>ACTION</th>
				<th>CREATED DATE</th>
				<th style="text-align:center">ACTION</th>
			</tr> 
		</thead> 
		<tbody>
		<?php
			$ctr =1;
		?>
			<?php $__currentLoopData = $hist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php
					 $iden= Crypt::encrypt($h->id);
				?>
				<tr>
					<td><?php echo e($ctr); ?></td>
					<td><?php echo e($h->users); ?></td>
					<td><?php echo e($h->module); ?></td>
					<td><?php echo e($h->action); ?></td>
					<td><?php echo e($h->created_at); ?></td>
					<td style="text-align:center" >
						<div class="btn-group" role="group" aria-label="..." >
							<a href="/history/view/<?php echo e($iden); ?>" class="btn btn-info glyphicon btn-xs glyphicon-eye-open" title="view"></a>
						</div>
					</td>
				</tr>

				<?php $ctr++ ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</tbody>
		
	</table>
</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>