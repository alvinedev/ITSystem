<?php $__env->startSection('title',$title); ?>

<?php $__env->startSection('titleHead'); ?>
    <ol class="breadcrumb">
    	<li><a href="/">HOME</a></li>
    	<li class="active">IP INVENTORY</li>

    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

	<div class="col-md-12">
		<a class="btn btn-primary btn-sm glyphicon glyphicon-plus" href="/ipinventory/create" role="button"><span style="font-family:arial;font-weight: bolder;font-size:15px">ADD</span></a>
	</div>
	<div>
		<?php if(count($ipinven) > 0): ?>
			<table class="table table-hover sub-table">
				<thead> 
				<tr> 
					<th>#</th> 
					<th>NAME</th>
					<th>DEPARTMENT</th>
					<th>IP ADDRESS</th>
					<th>CREATED DATE</th>
					<th>UPDATED DATE</th>
					<th>ACTIONS</th>
				</tr> 
				</thead> 
				<tbody>
				
				<?php
				$ctr = 1;
				?>

				<?php $__currentLoopData = $ipinven; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<th scope="row"><?php echo e($ctr); ?></th> 
					<td><?php echo e($ip->name); ?></td>
					<td><?php echo e($ip->location); ?></td>
					<td><?php echo e($ip->ipaddress); ?></td>
					<td><?php echo e($ip->created_at); ?></td>
					<td><?php echo e($ip->updated_at); ?></td>
					<td>

						<div class="btn-group" role="group" aria-label="...">
							<a href="/ipinventory/<?php echo e($ip->id); ?>" class="btn btn-info glyphicon btn-xs glyphicon-eye-open" title="view"></a>
							
							<a href="#" class="btn btn-danger glyphicon btn-xs glyphicon-trash" title="delete"></a>	
						</div>

					</td> 
				</tr>
					<?php $ctr++ ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

				</tbody> 
			</table>
			<div class="col-md-12" style="text-align:center">
					<?php echo e($ipinven->links()); ?>

			</div>
		<?php else: ?>
		<div style="text-align:center">
			No Record to Show
		</div>
		<?php endif; ?>	
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>