<?php $__env->startSection('title',$title); ?>

<?php $__env->startSection('body'); ?>
	<div class="col-md-4 col-md-offset-4">
		<?php echo Form::open(['action'=>'RegistrationsController@store','method'=>'POST']); ?>

		<?php echo e(csrf_field()); ?>

			<div class="form-group">
				<?php echo e(Form::label('name','USERNAME')); ?>

				<?php echo e(Form::text('name','',['class'=>'form-control'])); ?>

			</div>
			<div class="form-group">
				<?php echo e(Form::label('email','EMAIL')); ?>

				<?php echo e(Form::email('email','',['class'=>'form-control'])); ?>

			</div>
			<div class="form-group">
				<?php echo e(Form::label('password','PASSWORD')); ?>

				<input type="password" class="form-control" name="password" id="password">
			</div>
			<div class="form-group">
				<?php echo e(Form::label('password_confirmation','PASSWORD CONFIRMATION')); ?>

				<input type="password" class="form-control" name="password_confirmation" id="password_confirmation">
			</div>

			<?php echo e(Form::submit('REGISTER',['class'=>'btn btn-primary'])); ?>

		<?php echo Form::close(); ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>