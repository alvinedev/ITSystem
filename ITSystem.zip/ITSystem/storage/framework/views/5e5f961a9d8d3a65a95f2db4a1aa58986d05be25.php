<?php $__env->startSection('title',$title); ?>

<?php $__env->startSection('titleHead'); ?>
    <ol class="breadcrumb">
    	<li><a href="/">HOME</a></li>
    	<li><a href="/subjects">SUBJECTS</a></li>
    	<li class="active">DISPLAY</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
	<div class="col-md-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				 <span style="font-size:25px"><?php echo e($subject->name); ?></span><br />
				<div  style="float:right;margin:-40px 0 0 0">
				<small>Created Date: <?php echo e($subject->created_at); ?></small><br>
				<small>Updated Date: <?php echo e($subject->updated_at); ?></small>
				</div>
			</div>
			<div class="panel-body">
					<table class="col-md-12 table-des1">
						<tr>
							<th>DEPARTMENT</th>
							<td><?php echo e($subject->location); ?></td>
						</tr>
						<tr>
							<th>COMPUTER NAME</th>
							<td><?php echo e($subject->computer_name); ?></td>
						</tr>
						<tr>
							<th>DOMAIN NAME</th>
							<td><?php echo e($subject->domain_name); ?></td>
						</tr>


					</table>
			</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>