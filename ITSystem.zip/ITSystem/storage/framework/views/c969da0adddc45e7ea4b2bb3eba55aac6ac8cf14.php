<?php $__env->startSection('title','subject'); ?>

<?php $__env->startSection('body'); ?>
	<div class="col-md-12 header-text">
		<?php echo e($title); ?>

	</div>
	<div class="col-md-12">
		<div class="col-md-4">
		a
		</div>
		<div class="col-md-4">
		a
		</div>
		<div class="col-md-4">
		a
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>