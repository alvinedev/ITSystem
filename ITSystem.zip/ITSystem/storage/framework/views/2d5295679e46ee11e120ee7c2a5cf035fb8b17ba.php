<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" >
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>" >

        
        <title>IT SYSTEM - <?php echo $__env->yieldContent('title'); ?> </title>

    </head>
    <body>
    <?php echo $__env->make('include.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    	<div class="row">
    		<div class="container">
                <?php echo $__env->yieldContent('titleHead'); ?>
            <hr>


    		<div class="col-md-12">
    		    <?php echo $__env->make('include.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    		</div>

    			<?php echo $__env->yieldContent('body'); ?>
    			
    		</div>
    	</div>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery-3.2.1.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/action.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/ajax.js')); ?>"></script>
    </body>
</html>
