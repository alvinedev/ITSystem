<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('titleHead'); ?>
    <ol class="breadcrumb">
    	<li><a href="/">HOME</a></li>
    	<li><a href="/reports">REPORTS</a></li>
    	<li class="active">ADD</li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

	<div class="col-md-12">
		<?php echo Form::open(['action'=>'ReportsController@store','method'=>'POST']); ?>

		<div class="col-md-6">
			<div class="panel panel-default">
				<div class="panel-heading">INFORMATION</div>

				<div class="panel-body">
					<div class="form-group">
						<?php echo e(Form::label('reported_by','REPORTED BY')); ?>

						<select class="form-control report_select" name="reported_by" id="reported_by">
							<option value="0" selected disabled>Select</option>
							<?php $__currentLoopData = $sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
					<div class="form-group">
							<?php echo e(Form::label('location','DEPARTMENT')); ?>

							<?php echo e(Form::text('location','',['class'=>'form-control','readonly'=>'readonly'])); ?>

					</div>
					<div class="form-group">
							<?php echo e(Form::label('ticket','TICKET')); ?>

							<?php echo e(Form::text('ticket','A000001',['class'=>'form-control','readonly'=>'readonly'])); ?>

					</div>


				</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="panel panel-default">
				<div class="panel-heading">PROBLEM(S)</div>

				<div class="panel-body">
					<div class="form-group">
					<?php echo e(Form::label('problem','WRITE DOWN HERE')); ?>

					<?php echo e(Form::textarea('problem','',['class'=>'form-control'])); ?>

					</div>
				</div>
			</div>
		</div>
		<div class="col-md-12">
			<?php echo e(Form::submit('SAVE',['class'=>'btn btn-primary btn-block'])); ?>

		</div>
		<?php echo Form::close(); ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>