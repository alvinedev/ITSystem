<?php $__env->startSection('title',$title); ?>

<?php $__env->startSection('body'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>