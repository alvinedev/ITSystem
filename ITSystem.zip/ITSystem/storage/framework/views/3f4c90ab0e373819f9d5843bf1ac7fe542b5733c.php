<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('titleHead'); ?>
    <ol class="breadcrumb">
    	<li><a href="/">HOME</a></li>
    	<li><a href="/subjects">SUBJECTS</a></li>
    	<li class="active">ADD</li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

	<div class="col-md-12">
		<?php echo Form::open(['action'=>'SubjectsController@store','method'=>'POST']); ?>

			<div class="form-group">
				<?php echo e(Form::label('name','NAME:')); ?>

				<?php echo e(Form::text('name','',['class'=>'form-control','placeholder'=>'NAME'])); ?>

			</div>
			<div class="form-group">
				<?php echo e(Form::label('location','DEPARTMENT:')); ?>

				<select id="location" name="location" class="form-control">
					<option value="IT">IT</option>
					<option value="Creative">Creative</option>
					<option value="Online">Online</option>
					<option value="Inventory">Inventory</option>
					<option value="Accounting">Accounting</option>
					<option value="Admin">Admin</option>
					<option value="PDD">PDD</option>
					<option value="HR">HR</option>
					<option value="Production">Production</option>
					<option value="Franchise">Franchise</option>
					<option value="Purchasing">Purchasing</option>
					<option value="OTHER">OTHER</option>
				</select>
			</div>
			<div class="form-group">
				<?php echo e(Form::label('computer_name','COMPUTER NAME:')); ?>

				<?php echo e(Form::text('computer_name','',['class'=>'form-control','placeholder'=>'COMPUTER NAME'])); ?>

			</div>
			<div class="form-group">
				<?php echo e(Form::label('domain_name','DOMAIN NAME:')); ?>

				<?php echo e(Form::text('domain_name','',['class'=>'form-control','placeholder'=>'DOMAIN NAME'])); ?>

			</div>

				<?php echo e(Form::submit('SAVE',['class'=>'btn btn-primary btn-block'])); ?>

		<?php echo Form::close(); ?>


	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>